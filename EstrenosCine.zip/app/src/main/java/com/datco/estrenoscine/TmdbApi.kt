package com.datco.estrenoscine

import android.content.Context
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

fun JSONObject.str(k: String): String? =
    if (isNull(k)) null else optString(k).ifBlank { null }

class Repo(context: Context) {

    private val prefs = context.getSharedPreferences("cache_tmdb", Context.MODE_PRIVATE)

    // Descarga desde TMDB. Si no hay internet, usa lo ultimo guardado (modo sin conexion).
    private suspend fun get(path: String, params: Map<String, String>): JSONObject =
        withContext(Dispatchers.IO) {
            val claveCache = path + params.toSortedMap().toString()
            val q = (params + ("api_key" to Config.apiKey)).entries.joinToString("&") {
                "${it.key}=${URLEncoder.encode(it.value, "UTF-8")}"
            }
            val url = "${Config.BASE}$path?$q"
            val texto: String = try {
                val con = URL(url).openConnection() as HttpURLConnection
                con.connectTimeout = 10000
                con.readTimeout = 15000
                try {
                    if (con.responseCode != 200) throw IOException("HTTP ${con.responseCode}")
                    con.inputStream.bufferedReader().use { it.readText() }
                } finally {
                    con.disconnect()
                }
            } catch (e: IOException) {
                prefs.getString(claveCache, null) ?: throw e
            }
            if (prefs.all.size > 80) prefs.edit().clear().apply()
            prefs.edit().putString(claveCache, texto).apply()
            JSONObject(texto)
        }

    private fun aPelicula(o: JSONObject) = Pelicula(
        id = o.getInt("id"),
        titulo = o.str("title") ?: o.str("original_title") ?: "Sin título",
        resumen = o.str("overview") ?: "",
        poster = o.str("poster_path"),
        fondo = o.str("backdrop_path"),
        estreno = o.str("release_date") ?: "",
        puntaje = o.optDouble("vote_average", 0.0)
    )

    // tipo: "now_playing" (en cartelera) o "upcoming" (próximamente)
    // region: "AR" para Argentina, null para todo el mundo
    suspend fun estrenos(tipo: String, region: String?): List<Pelicula> {
        val res = mutableListOf<Pelicula>()
        for (pagina in 1..2) {
            val params = mutableMapOf("language" to "es-AR", "page" to pagina.toString())
            if (region != null) params["region"] = region
            var j: JSONObject? = null
            try {
                j = get("/movie/$tipo", params)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (pagina == 1) throw e
            }
            if (j == null) break
            val arr = j.getJSONArray("results")
            for (i in 0 until arr.length()) {
                res.add(aPelicula(arr.getJSONObject(i)))
            }
        }
        val lista = res.distinctBy { it.id }.filter { it.poster != null }
        return if (tipo == "upcoming") lista.sortedBy { it.estreno } else lista
    }

    suspend fun detalle(id: Int, base: Pelicula): Detalle {
        val j = get(
            "/movie/$id",
            mapOf(
                "language" to "es-AR",
                "append_to_response" to "credits,videos",
                "include_video_language" to "es,en,null"
            )
        )

        var resumen = j.str("overview") ?: ""
        if (resumen.isBlank()) {
            resumen = try {
                get("/movie/$id", mapOf("language" to "en-US")).str("overview") ?: ""
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                ""
            }
        }

        val generos = j.optJSONArray("genres")?.let { a ->
            (0 until a.length()).map { a.getJSONObject(it).optString("name") }
        } ?: emptyList()

        val productoras = j.optJSONArray("production_companies")?.let { a ->
            (0 until a.length()).map { a.getJSONObject(it).optString("name") }
        } ?: emptyList()

        val creditos = j.optJSONObject("credits")

        val elenco = creditos?.optJSONArray("cast")?.let { a ->
            (0 until minOf(a.length(), 12)).map {
                val o = a.getJSONObject(it)
                Persona(o.optString("name"), o.str("character") ?: "", o.str("profile_path"))
            }
        } ?: emptyList()

        val directores = creditos?.optJSONArray("crew")?.let { a ->
            (0 until a.length())
                .map { a.getJSONObject(it) }
                .filter { it.optString("job") == "Director" }
                .map { it.optString("name") }
        } ?: emptyList()

        val trailer = j.optJSONObject("videos")?.optJSONArray("results")?.let { a ->
            val vs = (0 until a.length())
                .map { a.getJSONObject(it) }
                .filter { it.optString("site") == "YouTube" }
            val elegido = vs.firstOrNull { it.optString("type") == "Trailer" }
                ?: vs.firstOrNull { it.optString("type") == "Teaser" }
            elegido?.optString("key")
        }

        return Detalle(
            pelicula = base.copy(resumen = resumen),
            generos = generos,
            duracion = j.optInt("runtime", 0),
            director = directores.distinct().joinToString(", "),
            productoras = productoras,
            elenco = elenco,
            trailerKey = trailer
        )
    }
}
