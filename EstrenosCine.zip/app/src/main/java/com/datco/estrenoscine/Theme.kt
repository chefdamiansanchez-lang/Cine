package com.datco.estrenoscine

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Fondo = Color(0xFF121110)
val Superficie = Color(0xFF1B1915)
val Tarjeta = Color(0xFF24211B)
val Amarillo = Color(0xFFD9B54A)
val SobreAmarillo = Color(0xFF1A1608)
val Texto = Color(0xFFEFE8D8)
val TextoSec = Color(0xFFA8A090)

@Composable
fun EstrenosTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Amarillo,
            onPrimary = SobreAmarillo,
            background = Fondo,
            onBackground = Texto,
            surface = Superficie,
            onSurface = Texto
        ),
        content = content
    )
}
