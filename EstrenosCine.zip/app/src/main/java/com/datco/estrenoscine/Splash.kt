package com.datco.estrenoscine

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun SplashDatco(onTerminar: () -> Unit) {
    val a = remember { Animatable(0f) }
    val e = remember { Animatable(0.85f) }

    LaunchedEffect(Unit) {
        launch { a.animateTo(1f, tween(800)) }
        launch { e.animateTo(1f, tween(800)) }
        delay(2300)
        onTerminar()
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xFF1B2028))
    ) {
        Column(
            modifier = Modifier
                .align(Alignment.Center)
                .graphicsLayer {
                    alpha = a.value
                    scaleX = e.value
                    scaleY = e.value
                },
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(96.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .background(
                        Brush.linearGradient(listOf(Color(0xFF007BC7), Color(0xFF00D2FF)))
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text("D", color = Color.White, fontSize = 54.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(22.dp))
            Text(
                "DATCO",
                color = Color.White,
                fontSize = 34.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 10.sp
            )
            Spacer(Modifier.height(10.dp))
            Text(
                "Desarrollo Avanzado de Tecnologías\ny Códigos Operativos",
                color = Color(0xFF8FA0B3),
                fontSize = 12.sp,
                textAlign = TextAlign.Center,
                letterSpacing = 1.sp
            )
        }
        Text(
            "Diseño de apps... y algo más",
            color = Color(0xFF6B7A8C),
            fontSize = 12.sp,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 40.dp)
        )
    }
}
