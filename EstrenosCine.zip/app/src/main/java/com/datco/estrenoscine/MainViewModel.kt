package com.datco.estrenoscine

import android.app.Application
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = Repo(app)
    private val favPrefs = app.getSharedPreferences("favoritos", Context.MODE_PRIVATE)
    private var job: Job? = null

    // Estrenos
    var region by mutableStateOf("AR")          // "AR" o "WORLD"
    var tipo by mutableStateOf("now_playing")   // "now_playing" o "upcoming"
    var lista by mutableStateOf<List<Pelicula>>(emptyList())
    var cargando by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)

    // Ficha de película
    var seleccion by mutableStateOf<Pelicula?>(null)
    var detalle by mutableStateOf<Detalle?>(null)
    var errorDetalle by mutableStateOf(false)

    // Favoritos
    var favoritos by mutableStateOf<List<Pelicula>>(leerFavoritos())

    init {
        cargar()
    }

    fun cargar() {
        job?.cancel()
        job = viewModelScope.launch {
            cargando = true
            error = null
            try {
                lista = repo.estrenos(tipo, if (region == "AR") "AR" else null)
                cargando = false
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                lista = emptyList()
                error = if (!Config.claveValida) {
                    "Falta la clave de TMDB.\nPegala en Config.kt o creá el secreto TMDB_API_KEY en GitHub."
                } else {
                    "No se pudieron cargar los estrenos.\nRevisá tu conexión a internet."
                }
                cargando = false
            }
        }
    }

    fun elegirRegion(r: String) {
        if (r != region) {
            region = r
            lista = emptyList()
            cargar()
        }
    }

    fun elegirTipo(t: String) {
        if (t != tipo) {
            tipo = t
            lista = emptyList()
            cargar()
        }
    }

    fun abrir(p: Pelicula) {
        seleccion = p
        detalle = null
        errorDetalle = false
        viewModelScope.launch {
            try {
                val d = repo.detalle(p.id, p)
                if (seleccion?.id == p.id) detalle = d
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (seleccion?.id == p.id) errorDetalle = true
            }
        }
    }

    fun cerrar() {
        seleccion = null
        detalle = null
        errorDetalle = false
    }

    fun esFav(id: Int): Boolean = favoritos.any { it.id == id }

    fun alternarFav(p: Pelicula) {
        favoritos = if (esFav(p.id)) {
            favoritos.filter { it.id != p.id }
        } else {
            favoritos + p
        }
        guardarFavoritos()
    }

    private fun leerFavoritos(): List<Pelicula> {
        val txt = favPrefs.getString("lista", "[]") ?: "[]"
        return try {
            val arr = JSONArray(txt)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Pelicula(
                    id = o.getInt("id"),
                    titulo = o.str("titulo") ?: "Sin título",
                    resumen = o.str("resumen") ?: "",
                    poster = o.str("poster"),
                    fondo = o.str("fondo"),
                    estreno = o.str("estreno") ?: "",
                    puntaje = o.optDouble("puntaje", 0.0)
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun guardarFavoritos() {
        val arr = JSONArray()
        favoritos.forEach { f ->
            val o = JSONObject()
            o.put("id", f.id)
            o.put("titulo", f.titulo)
            o.put("resumen", f.resumen)
            o.put("poster", f.poster ?: JSONObject.NULL)
            o.put("fondo", f.fondo ?: JSONObject.NULL)
            o.put("estreno", f.estreno)
            o.put("puntaje", f.puntaje)
            arr.put(o)
        }
        favPrefs.edit().putString("lista", arr.toString()).apply()
    }
}
