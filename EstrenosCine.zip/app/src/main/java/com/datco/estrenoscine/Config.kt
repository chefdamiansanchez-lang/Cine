package com.datco.estrenoscine

object Config {
    // OPCION A: pegar tu clave de TMDB entre las comillas (reemplazando el texto).
    // OPCION B: crear el secreto TMDB_API_KEY en GitHub (no hace falta tocar este archivo).
    private const val CLAVE_MANUAL = "PEGAR_TU_CLAVE_AQUI"

    val apiKey: String
        get() = BuildConfig.TMDB_KEY.ifBlank { CLAVE_MANUAL }

    val claveValida: Boolean
        get() = apiKey.isNotBlank() && apiKey != CLAVE_MANUAL

    const val BASE = "https://api.themoviedb.org/3"
    const val IMG = "https://image.tmdb.org/t/p/"
}
