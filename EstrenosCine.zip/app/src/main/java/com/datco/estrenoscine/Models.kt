package com.datco.estrenoscine

data class Pelicula(
    val id: Int,
    val titulo: String,
    val resumen: String,
    val poster: String?,
    val fondo: String?,
    val estreno: String,
    val puntaje: Double
)

data class Persona(
    val nombre: String,
    val personaje: String,
    val foto: String?
)

data class Detalle(
    val pelicula: Pelicula,
    val generos: List<String>,
    val duracion: Int,
    val director: String,
    val productoras: List<String>,
    val elenco: List<Persona>,
    val trailerKey: String?
)

fun fechaLinda(s: String): String {
    val p = s.split("-")
    return if (p.size == 3) "${p[2]}/${p[1]}/${p[0]}" else "Fecha a confirmar"
}
