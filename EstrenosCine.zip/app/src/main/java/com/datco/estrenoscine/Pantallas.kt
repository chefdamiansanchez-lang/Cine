package com.datco.estrenoscine

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import java.net.URLEncoder

// Cines de Argentina (se abre la web oficial de cada uno)
private val CINES = listOf(
    "Cinemark Hoyts" to "https://www.cinemarkhoyts.com.ar",
    "Cinépolis" to "https://www.cinepolis.com.ar",
    "Showcase" to "https://www.todoshowcase.com"
)

fun abrirUrl(ctx: Context, url: String) {
    try {
        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    } catch (e: Exception) {
        // sin navegador disponible: no hacemos nada
    }
}

fun compartir(ctx: Context, p: Pelicula) {
    try {
        val i = Intent(Intent.ACTION_SEND)
        i.type = "text/plain"
        i.putExtra(
            Intent.EXTRA_TEXT,
            "🎬 ${p.titulo} - estreno ${fechaLinda(p.estreno)}\nhttps://www.themoviedb.org/movie/${p.id}"
        )
        ctx.startActivity(Intent.createChooser(i, "Compartir película"))
    } catch (e: Exception) {
        // nada
    }
}

@Composable
fun Principal(vm: MainViewModel) {
    val sel = vm.seleccion
    BackHandler(enabled = sel != null) { vm.cerrar() }

    if (sel != null) {
        PantallaDetalle(vm, sel)
    } else {
        var tab by rememberSaveable { mutableIntStateOf(0) }
        Scaffold(
            containerColor = Fondo,
            bottomBar = {
                NavigationBar(containerColor = Superficie) {
                    val colores = NavigationBarItemDefaults.colors(
                        selectedIconColor = SobreAmarillo,
                        selectedTextColor = Amarillo,
                        indicatorColor = Amarillo,
                        unselectedIconColor = TextoSec,
                        unselectedTextColor = TextoSec
                    )
                    NavigationBarItem(
                        selected = tab == 0,
                        onClick = { tab = 0 },
                        icon = { Icon(Icons.Default.Home, contentDescription = null) },
                        label = { Text("Estrenos") },
                        colors = colores
                    )
                    NavigationBarItem(
                        selected = tab == 1,
                        onClick = { tab = 1 },
                        icon = { Icon(Icons.Default.Favorite, contentDescription = null) },
                        label = { Text("Favoritos") },
                        colors = colores
                    )
                }
            }
        ) { pad ->
            Box(
                Modifier
                    .padding(pad)
                    .fillMaxSize()
            ) {
                if (tab == 0) PantallaEstrenos(vm) else PantallaFavoritos(vm)
            }
        }
    }
}

@Composable
fun Pastilla(texto: String, activa: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(if (activa) Amarillo else Superficie)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Text(
            texto,
            color = if (activa) SobreAmarillo else TextoSec,
            fontWeight = FontWeight.SemiBold,
            fontSize = 14.sp
        )
    }
}

@Composable
fun PantallaEstrenos(vm: MainViewModel) {
    val err = vm.error
    Column(
        Modifier
            .fillMaxSize()
            .background(Fondo)
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(start = 16.dp, end = 4.dp, top = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Estrenos",
                color = Texto,
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )
            IconButton(onClick = { vm.cargar() }) {
                Icon(Icons.Default.Refresh, contentDescription = "Actualizar", tint = Amarillo)
            }
        }
        Row(
            Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Pastilla("Argentina", vm.region == "AR") { vm.elegirRegion("AR") }
            Pastilla("Mundo", vm.region == "WORLD") { vm.elegirRegion("WORLD") }
        }
        Row(
            Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Pastilla("En cartelera", vm.tipo == "now_playing") { vm.elegirTipo("now_playing") }
            Pastilla("Próximamente", vm.tipo == "upcoming") { vm.elegirTipo("upcoming") }
        }
        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            when {
                vm.cargando && vm.lista.isEmpty() -> {
                    CircularProgressIndicator(
                        color = Amarillo,
                        modifier = Modifier.align(Alignment.Center)
                    )
                }
                err != null && vm.lista.isEmpty() -> {
                    Column(
                        Modifier
                            .align(Alignment.Center)
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(err, color = TextoSec, textAlign = TextAlign.Center)
                        Spacer(Modifier.height(16.dp))
                        Button(
                            onClick = { vm.cargar() },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Amarillo,
                                contentColor = SobreAmarillo
                            )
                        ) { Text("Reintentar") }
                    }
                }
                vm.lista.isEmpty() -> {
                    Text(
                        "No hay estrenos para mostrar.",
                        color = TextoSec,
                        modifier = Modifier.align(Alignment.Center)
                    )
                }
                else -> {
                    GrillaPeliculas(vm.lista, vm)
                    if (vm.cargando) {
                        LinearProgressIndicator(
                            modifier = Modifier
                                .fillMaxWidth()
                                .align(Alignment.TopCenter),
                            color = Amarillo,
                            trackColor = Superficie
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun PantallaFavoritos(vm: MainViewModel) {
    Column(
        Modifier
            .fillMaxSize()
            .background(Fondo)
    ) {
        Text(
            "Favoritos",
            color = Texto,
            fontSize = 26.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(start = 16.dp, top = 12.dp, bottom = 8.dp)
        )
        if (vm.favoritos.isEmpty()) {
            Box(
                Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "Todavía no guardaste ninguna película.\nTocá el corazón en la ficha de una película para agregarla acá.",
                    color = TextoSec,
                    textAlign = TextAlign.Center
                )
            }
        } else {
            GrillaPeliculas(vm.favoritos, vm)
        }
    }
}

@Composable
fun GrillaPeliculas(peliculas: List<Pelicula>, vm: MainViewModel) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        contentPadding = PaddingValues(12.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        items(peliculas, key = { it.id }) { p ->
            TarjetaPelicula(p, vm.esFav(p.id)) { vm.abrir(p) }
        }
    }
}

@Composable
fun TarjetaPelicula(p: Pelicula, esFav: Boolean, onClick: () -> Unit) {
    Column(
        Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(Tarjeta)
            .clickable(onClick = onClick)
    ) {
        Box {
            if (p.poster != null) {
                AsyncImage(
                    model = Config.IMG + "w342" + p.poster,
                    contentDescription = p.titulo,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(2f / 3f)
                )
            } else {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .aspectRatio(2f / 3f)
                        .background(Superficie),
                    contentAlignment = Alignment.Center
                ) { Text("🎬", fontSize = 40.sp) }
            }
            if (esFav) {
                Icon(
                    Icons.Default.Favorite,
                    contentDescription = null,
                    tint = Amarillo,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(8.dp)
                        .size(22.dp)
                )
            }
        }
        Column(Modifier.padding(10.dp)) {
            Text(
                p.titulo,
                color = Texto,
                fontWeight = FontWeight.SemiBold,
                fontSize = 14.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(4.dp))
            Text(fechaLinda(p.estreno), color = TextoSec, fontSize = 12.sp)
        }
    }
}

@Composable
fun Seccion(titulo: String) {
    Text(
        titulo,
        color = Amarillo,
        fontSize = 16.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(top = 20.dp, bottom = 6.dp)
    )
}

@Composable
fun PantallaDetalle(vm: MainViewModel, p: Pelicula) {
    val ctx = LocalContext.current
    val d = vm.detalle
    val pel = d?.pelicula ?: p
    val fav = vm.esFav(p.id)

    Column(
        Modifier
            .fillMaxSize()
            .background(Fondo)
            .verticalScroll(rememberScrollState())
    ) {
        Box {
            val img = pel.fondo ?: pel.poster
            if (img != null) {
                AsyncImage(
                    model = Config.IMG + (if (pel.fondo != null) "w780" else "w500") + img,
                    contentDescription = pel.titulo,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(230.dp)
                )
            } else {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(230.dp)
                        .background(Superficie)
                )
            }
            IconButton(
                onClick = { vm.cerrar() },
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(8.dp)
                    .background(Color(0x99000000), CircleShape)
            ) {
                Icon(
                    Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Volver",
                    tint = Color.White
                )
            }
            IconButton(
                onClick = { vm.alternarFav(pel) },
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(8.dp)
                    .background(Color(0x99000000), CircleShape)
            ) {
                Icon(
                    if (fav) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                    contentDescription = "Favorito",
                    tint = Amarillo
                )
            }
        }

        Column(Modifier.padding(16.dp)) {
            Text(pel.titulo, color = Texto, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))

            val partes = mutableListOf(fechaLinda(pel.estreno))
            if (d != null && d.duracion > 0) {
                partes.add("${d.duracion / 60}h ${d.duracion % 60}min")
            }
            if (pel.puntaje > 0) {
                partes.add("★ " + "%.1f".format(pel.puntaje))
            }
            Text(partes.joinToString("  •  "), color = TextoSec, fontSize = 13.sp)

            if (d != null && d.generos.isNotEmpty()) {
                Spacer(Modifier.height(4.dp))
                Text(d.generos.joinToString(" · "), color = TextoSec, fontSize = 13.sp)
            }

            Seccion("Reseña")
            Text(
                if (pel.resumen.isBlank()) "Sin reseña disponible todavía." else pel.resumen,
                color = Texto,
                fontSize = 15.sp,
                lineHeight = 22.sp
            )

            if (d == null) {
                Spacer(Modifier.height(16.dp))
                if (vm.errorDetalle) {
                    Text(
                        "No se pudo cargar el elenco ni el director. Revisá tu conexión.",
                        color = TextoSec,
                        fontSize = 13.sp
                    )
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(
                            color = Amarillo,
                            modifier = Modifier.size(18.dp),
                            strokeWidth = 2.dp
                        )
                        Spacer(Modifier.width(10.dp))
                        Text("Cargando ficha completa…", color = TextoSec, fontSize = 13.sp)
                    }
                }
            } else {
                Seccion("Dirección")
                Text(
                    if (d.director.isBlank()) "No informado" else d.director,
                    color = Texto,
                    fontSize = 15.sp
                )

                Seccion("Elenco principal")
                if (d.elenco.isEmpty()) {
                    Text("No informado", color = Texto, fontSize = 15.sp)
                } else {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        items(d.elenco) { a ->
                            Column(
                                Modifier.width(84.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                if (a.foto != null) {
                                    AsyncImage(
                                        model = Config.IMG + "w185" + a.foto,
                                        contentDescription = a.nombre,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier
                                            .size(72.dp)
                                            .clip(CircleShape)
                                    )
                                } else {
                                    Box(
                                        Modifier
                                            .size(72.dp)
                                            .clip(CircleShape)
                                            .background(Tarjeta),
                                        contentAlignment = Alignment.Center
                                    ) { Text("👤", fontSize = 28.sp) }
                                }
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    a.nombre,
                                    color = Texto,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 2,
                                    textAlign = TextAlign.Center,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    a.personaje,
                                    color = TextoSec,
                                    fontSize = 11.sp,
                                    maxLines = 2,
                                    textAlign = TextAlign.Center,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }

                Seccion("Productoras")
                Text(
                    if (d.productoras.isEmpty()) "No informado" else d.productoras.joinToString(" · "),
                    color = Texto,
                    fontSize = 15.sp
                )

                if (d.trailerKey != null) {
                    Spacer(Modifier.height(20.dp))
                    Button(
                        onClick = { abrirUrl(ctx, "https://www.youtube.com/watch?v=${d.trailerKey}") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Amarillo,
                            contentColor = SobreAmarillo
                        )
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text("Ver tráiler", fontWeight = FontWeight.Bold)
                    }
                }
            }

            Seccion("Ver en cines de Argentina")
            Text(
                "Se abre la web de cada cine para ver horarios y comprar entradas.",
                color = TextoSec,
                fontSize = 13.sp
            )
            Spacer(Modifier.height(8.dp))
            val bordeAmarillo = BorderStroke(1.dp, Amarillo)
            val colorBoton = ButtonDefaults.outlinedButtonColors(contentColor = Amarillo)
            CINES.forEach { (nombre, url) ->
                OutlinedButton(
                    onClick = { abrirUrl(ctx, url) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp),
                    border = bordeAmarillo,
                    colors = colorBoton
                ) { Text(nombre) }
            }
            OutlinedButton(
                onClick = {
                    val q = URLEncoder.encode("${pel.titulo} horarios cines Argentina", "UTF-8")
                    abrirUrl(ctx, "https://www.google.com/search?q=$q")
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 3.dp),
                border = bordeAmarillo,
                colors = colorBoton
            ) { Text("Buscar horarios en Google") }

            Spacer(Modifier.height(12.dp))
            OutlinedButton(
                onClick = { compartir(ctx, pel) },
                modifier = Modifier.fillMaxWidth(),
                border = bordeAmarillo,
                colors = colorBoton
            ) {
                Icon(Icons.Default.Share, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text("Compartir")
            }

            Spacer(Modifier.height(24.dp))
            Text(
                "Datos e imágenes: TMDB. Este producto usa la API de TMDB pero no está avalado ni certificado por TMDB.",
                color = TextoSec,
                fontSize = 11.sp
            )
        }
    }
}
